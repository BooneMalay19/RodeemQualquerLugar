import requests

def get_ascii_image():
    response = requests.get('http://localhost:8080/video_feed', stream=True)

    if response.status_code == 200:
        print(f"Tipo de Conteúdo: {response.headers['Content-Type']}")
        # Processar o fluxo de vídeo
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                # Aqui você pode processar a imagem e exibir como ASCII ou fazer qualquer outro processamento
                print("Imagem recebida!")
    else:
        print(f"Erro ao acessar o feed de vídeo: {response.status_code}")

if __name__ == '__main__':
    get_ascii_image()
