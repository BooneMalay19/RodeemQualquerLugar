(function() {
    // Função para substituir todos os vídeos
    function replaceVideo() {
        // Buscando todos os elementos de vídeo
        const videos = document.querySelectorAll('video');
        
        videos.forEach(video => {
            // Substitui o src do vídeo pelo feed de vídeo do Flask
            video.src = "http://10.111.39.69:8080/video_feed";  // Substitua <SEU_IP> pelo IP do seu servidor
            video.play(); // Tenta iniciar o vídeo
        });
    }

    // Substituir vídeos assim que a página carregar
    window.addEventListener('load', replaceVideo);

    // Observador de mudanças no DOM para vídeos carregados dinamicamente
    const observer = new MutationObserver(replaceVideo);
    observer.observe(document.body, { childList: true, subtree: true });
})();
