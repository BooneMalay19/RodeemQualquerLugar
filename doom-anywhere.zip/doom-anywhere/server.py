from flask import Flask, Response, request, render_template
from PIL import Image
import io
import win32gui, win32ui, win32con, win32api

app = Flask(__name__)

WINDOW_TITLE = 'DOOM Shareware - Chocolate Doom 3.1.0'

# Função para capturar a janela do DOOM
def capture_window(title):
    hwnd = win32gui.FindWindow(None, title)
    if not hwnd:
        return None
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    w, h = right - left, bottom - top
    hwindc = win32gui.GetWindowDC(hwnd)
    srcdc = win32ui.CreateDCFromHandle(hwindc)
    memdc = srcdc.CreateCompatibleDC()
    bmp = win32ui.CreateBitmap()
    bmp.CreateCompatibleBitmap(srcdc, w, h)
    memdc.SelectObject(bmp)
    memdc.BitBlt((0, 0), (w, h), srcdc, (0, 0), win32con.SRCCOPY)
    bmpinfo = bmp.GetInfo()
    bmpstr = bmp.GetBitmapBits(True)
    img = Image.frombuffer('RGB', (bmpinfo['bmWidth'], bmpinfo['bmHeight']), bmpstr, 'raw', 'BGRX', 0, 1)
    srcdc.DeleteDC()
    memdc.DeleteDC()
    win32gui.ReleaseDC(hwnd, hwindc)
    win32gui.DeleteObject(bmp.GetHandle())
    return img

# Gera os frames de captura
def generate_frames():
    while True:
        img = capture_window(WINDOW_TITLE)
        if img:
            buf = io.BytesIO()
            img.save(buf, format='JPEG')
            frame = buf.getvalue()
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')  # Página de vídeo onde o DOOM vai ser exibido

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Função para enviar teclas para o DOOM
@app.route('/send_key', methods=['POST'])
def send_key():
    key = request.json['key']
    key_map = {'w': 0x57, 'a': 0x41, 's': 0x53, 'd': 0x44, 'space': 0x20}
    code = key_map.get(key.lower())
    if code:
        win32api.keybd_event(code, 0, 0, 0)
        win32api.keybd_event(code, 0, win32con.KEYEVENTF_KEYUP, 0)
    return 'OK', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
